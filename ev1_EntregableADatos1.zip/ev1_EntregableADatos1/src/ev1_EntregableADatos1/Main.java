package ev1_EntregableADatos1;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main {
	
	public static String getInformacion(File directorio) {
		
		
		if(directorio.isFile() == true) {
			
		return directorio.getName() + " " + directorio.isFile() + " " + directorio.getTotalSpace() 
				+ " " + directorio.getAbsolutePath() +  " " + directorio.lastModified() + " " + directorio.isHidden();
		}
		
		if(directorio.isDirectory() == true) {
			
			 return directorio.getName() + " " + directorio.isDirectory() +" " +  directorio.list().length + " " + 
			directorio.getUsableSpace() + " " + directorio.getTotalSpace()+ " " + directorio.getAbsolutePath() +  " " + directorio.lastModified();
		}
		
		
		return null;
		
	}
	
	public static String crearCarpeta (String nuevoDirect) {
		
		File nuevoDirectorio = new File (nuevoDirect);
		String respuesta = "directorio creado correctamente";
		
		if (nuevoDirectorio.mkdir()) {
			
			return respuesta + " " +  nuevoDirectorio.getAbsolutePath();
			
		}
		
		return null;
	
		
	}
	
	public static String crearFichero(String directorio)  {
		
		File nuevoFichero = new File (directorio);
		
		try {
			if(nuevoFichero.createNewFile()) {
				
				return "fichero creado correctamente " + nuevoFichero.getAbsolutePath();
			}
			
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}
	
	public static String eliminarFichero (String fichero) {
		
		File fich = new File (fichero);
		
		if (fich.delete()) {
			
			
			return "fichero eliminado correctamente";
		}
		
		return null;
	}
	
	public static String renombrarFichero (String fichero, String nombre) {
		
		File fRenombrar = new File(fichero);
		File fNuevo = new File(nombre);
		
		fRenombrar.renameTo(fNuevo);
		
		return "cambio de nombre correctaente";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Dime el directorio");
		String direc = teclado.next();
		
		//mostrar informacion
		File directorio = new File (direc);
		
		String info = getInformacion(directorio);
		
		System.out.println(info);
		
		
		//crear nuevo directorio
		System.out.println("Dime como quieres que se llame el nuevo directorio, pon la ruta absoluta");
		String nuevoDirect = teclado.next() ;
		
		
		String resp = crearCarpeta(nuevoDirect);
		
		System.out.println(resp);
		
		//crear nuevo fichero
		
		System.out.println("Dime como quieres que se llame el nuevo fichero, pon la ruta absoluta");
		String fichero = teclado.next();
		String nuevoFich = crearFichero(fichero);
		System.out.println(nuevoFich);
		
		
		//Eliminar Fichero
		
		System.out.println("Dime el fichero que quieres eliminar, pon la ruta absoluta");
		String eliminar = teclado.next();
	
		String eliminarFich = eliminarFichero(eliminar);
		System.out.println(eliminarFich);
		
		//Dime a que fichero quieres cambiarle el nombre
		
		System.out.println("Dime el fichero que quieres cambiar el nombre, pon la ruta absoluta");
		String renombrar = teclado.next();
		
		System.out.println("Dime el nombre al que lo quieres cambiar, pon la ruta absoluta");
		String cambioNombre = teclado.next();
		
		String renombr = renombrarFichero(renombrar, cambioNombre);
		System.out.println(renombr);
		
		

	}

}
