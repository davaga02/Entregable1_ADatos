package ev1_EntregableADatos1;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main {
	
	public static String getInformacion(File directorio) {
		
		
		if(directorio.isFile() == true) {
			
		return directorio.getName() + " " + directorio.isFile() + " " + directorio.getTotalSpace() 
				+ " " + directorio.getAbsolutePath() +  " " + directorio.lastModified() + " " + directorio.isHidden();
		}
		
		if(directorio.isDirectory() == true) {
			
			 return directorio.getName() + " " + directorio.isDirectory() +" " +  directorio.list().length + " " + 
			directorio.getUsableSpace() + " " + directorio.getTotalSpace()+ " " + directorio.getAbsolutePath() +  " " + directorio.lastModified();
		}
		
		
		return null;
		
	}
	
	public static String crearCarpeta (File nuevoDirectorio) {
		
		String respuesta = "directorio creado correctamente";
		
		if (nuevoDirectorio.mkdir()) {
			
			return respuesta + " " +  nuevoDirectorio.getAbsolutePath();
			
		}
		
		return null;
	
		
	}
	
	public static String crearFichero(File directorio)  {
		
		try {
			if(directorio.createNewFile()) {
				
				return "fichero creado correctamente " + directorio.getAbsolutePath();
			}
			
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}
	
	public static String eliminarFichero (File fichero) {
		
		if (fichero.exists()) {
			
			fichero.delete();
			return "fichero eliminado correctamente";
		}
		
		return null;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Dime el directorio");
		String direc = teclado.next();
		
		//mostrar informacion
		File directorio = new File (direc);
		
		String info = getInformacion(directorio);
		
		System.out.println(info);
		
		
		//crear nuevo directorio
		System.out.println("Dime como quieres que se llame el nuevo directorio");
		String nuevoDirect = teclado.next() ;
		
		File nuevoDirectorio  =  new File(nuevoDirect);
		String resp = crearCarpeta(nuevoDirectorio);
		
		System.out.println(resp);
		
		//crear nuevo fichero
		
		String nuevoFich = crearFichero(directorio);
		System.out.println(nuevoFich);
		
		
		//Eliminar Fichero
		
		System.out.println("Dime el fichero que quieres eliminar");
		String eliminar = teclado.next();
		
		File ficheroEliminar = new File(eliminar);
		
		String eliminarFich = eliminarFichero(ficheroEliminar);
		System.out.println(eliminarFich);
		
		
		

	}

}
