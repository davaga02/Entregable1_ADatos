package entregableADatos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

public class Model {
	
	public Model() {
		
	}

	static String ruta = "AE02_T1_2_Streams_Groucho.txt";
	static File f = new File(ruta);
	static ArrayList<String> lineas = new ArrayList<String>(); 
	
	
	
	public static ArrayList<String> mostrarTexto () {
		
		try{
			
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
			
			String linea;
			
			
			
			while ((linea = br.readLine()) != null) {
				
				lineas.add(linea);
				
			}
			
			
			
			fr.close();
			br.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return lineas;
		
	}
	
	public static int buscarPalabra(String palabra) {
		
		String[] palabrasSeparadas;
		int cont = 0;
		
		try {
			
			
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
			
			String linea;
			
			while((linea = br.readLine()) != null) {
				
				palabrasSeparadas = linea.split(" ");
				
				
				for(int i = 0; i < palabrasSeparadas.length; i++) {
					
					if(palabrasSeparadas[i].equals(palabra)) {
						
						cont++;
					}
				}
				
			}
			
			fr.close();
			br.close();
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return cont;
		
		
	}
	
	public static ArrayList<String> reemplazarPalabra(String palabra, String palabraNueva) {
		
		try {
			
			String[] palabrasSeparadas;
		
			
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
			
			String linea;
			
			while((linea = br.readLine()) != null) {
				
				palabrasSeparadas = linea.split(" ");
				
				
				for(int i = 0; i < palabrasSeparadas.length; i++) {
					
					if(palabrasSeparadas[i].equals(palabra)) {
						
						lineas.add(palabraNueva);
					}else {
						lineas.add(palabrasSeparadas[i]);
					}
				}
			
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return lineas;
	}
	
	

}
