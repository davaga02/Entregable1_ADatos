package entregableADatos;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Controlador {
	
	static private Vista vista;
	static private Model modelo;
	
	public Controlador(Vista vista, Model modelo) {

		this.vista = vista;
		this.modelo = modelo;
		mostrarTxt();
		buscarPalabras();
		reemplazarPalabras();
	}
	
	public void mostrarTxt () {
		
		vista.getTextAreaOriginal().setText(Model.mostrarTexto().toString());
	
		
	}
	
	public void buscarPalabras() {
		
		vista.getBtnBuscar().addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				
				String palabra = vista.getTextFieldBuscar().getText();
				int numeroVeces = Model.buscarPalabra(palabra);
				
				
				JOptionPane.showMessageDialog(new JFrame (), "veces " + numeroVeces ,"Total", JOptionPane.INFORMATION_MESSAGE);
				
			}

	});
	
	}
	
	public void reemplazarPalabras() {
		
		vista.getBtnReemplazar().addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
		
				String palabra = vista.getTextFieldBuscar().getText();
				String rPalabra = vista.getTextFieldReemplazar().getText();
		
				vista.getTextAreaModificado().setText(Model.reemplazarPalabra(palabra, rPalabra).toString());
				
			}
			
		});
		
	}
	
}
	


